"""
This is the Template Repl for Python with Turtle.

Python with Turtle lets you make graphics easily in Python.

Check out the official docs here: https://docs.python.org/3/library/turtle.html
"""

import turtle

t = turtle.Turtle()
"""
for c in ['red', 'black', 'green', 'black']:
    t.color(c)
    t.forward(75)
    t.right(90)
"""
# idk what im doin
for c in ['red','blue','green','orange']:
    t.color(c)
    t.forward(100)
    t.left(90)
    t.forward(100)
    t.left(90)
    t.forward(100)
    t.left(90)
    t.forward(100)
    t.left(120)
    t.forward(100)
    t.left(120)
    t.forward(100)
    t.left(240)
    t.forward(115)
    t.left(240)
    t.forward(140)